//
//  HoldingMainModel+CoreDataClass.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
//

public import Foundation
public import CoreData

public typealias HoldingMainModelCoreDataClassSet = NSSet

@objc(HoldingMainModel)
public class HoldingMainModel: NSManagedObject, Decodable {
    
    enum CodingKeys: String, CodingKey {
        case data
    }
    
    required convenience public init(from decoder: Decoder) throws {
        guard let context = decoder.userInfo[CodingUserInfoKey.context] as? NSManagedObjectContext
        else {
            throw ContextError.contextNotFound
        }
        
        self.init(entity: HoldingMainModel.entity(), insertInto: context)
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.holdingData = try container.decodeIfPresent(HoldingData.self, forKey: .data)
    }
}
