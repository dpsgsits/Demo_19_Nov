//
//  HoldingData+CoreDataProperties.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
//

public import Foundation
public import CoreData


public typealias HoldingDataCoreDataPropertiesSet = NSSet

extension HoldingData {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<HoldingData> {
        return NSFetchRequest<HoldingData>(entityName: "HoldingData")
    }

    @NSManaged public var userHolding: Set<Holding>?
    @NSManaged public var holdingMainModel: HoldingMainModel?

}

// MARK: Generated accessors for userHolding
extension HoldingData {

    @objc(addUserHoldingObject:)
    @NSManaged public func addToUserHolding(_ value: Holding)

    @objc(removeUserHoldingObject:)
    @NSManaged public func removeFromUserHolding(_ value: Holding)

    @objc(addUserHolding:)
    @NSManaged public func addToUserHolding(_ values: NSSet)

    @objc(removeUserHolding:)
    @NSManaged public func removeFromUserHolding(_ values: NSSet)

}

extension HoldingData : Identifiable {

}
