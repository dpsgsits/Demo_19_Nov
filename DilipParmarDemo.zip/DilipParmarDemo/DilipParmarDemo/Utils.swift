//
//  Utils.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 19/11/25.
//

import Foundation

struct Utils {
    static var isUnitTesting: Bool {
        ProcessInfo.processInfo.environment["XCTestConfigurationFilePath"] != nil
    }
}
