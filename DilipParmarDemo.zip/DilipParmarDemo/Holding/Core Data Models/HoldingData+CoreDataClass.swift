//
//  HoldingData+CoreDataClass.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
//

public import Foundation
public import CoreData

public typealias HoldingDataCoreDataClassSet = NSSet

@objc(HoldingData)
public class HoldingData: NSManagedObject, Decodable {
    
    enum CodingKeys: String, CodingKey {
        case userHolding
    }
    
    required convenience public init(from decoder: Decoder) throws {
        guard let context = decoder.userInfo[CodingUserInfoKey.context] as? NSManagedObjectContext
        else {
            throw ContextError.contextNotFound
        }
        
        self.init(entity: HoldingData.entity(), insertInto: context)
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.userHolding = try container.decodeIfPresent(Set<Holding>.self, forKey: .userHolding)
    }
}
