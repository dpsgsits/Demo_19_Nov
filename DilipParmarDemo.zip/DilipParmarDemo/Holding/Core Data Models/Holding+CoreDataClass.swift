//
//  Holding+CoreDataClass.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
//

public import Foundation
public import CoreData

public typealias HoldingCoreDataClassSet = NSSet

@objc(Holding)
public class Holding: NSManagedObject, Decodable {
    
    enum CodingKeys: String, CodingKey {
        case symbol, quantity, ltp, avgPrice, close
    }
    
    required convenience public init(from decoder: Decoder) throws {
        guard let context = decoder.userInfo[CodingUserInfoKey.context] as? NSManagedObjectContext
        else {
            throw ContextError.contextNotFound
        }
        
        self.init(entity: Holding.entity(), insertInto: context)
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        symbol = try container.decodeIfPresent(String.self, forKey: .symbol)
        quantity = try container.decodeIfPresent(Int64.self, forKey: .quantity) ?? 0
        ltp = try container.decodeIfPresent(Double.self, forKey: .ltp) ?? 0.0
        avgPrice = try container.decodeIfPresent(Double.self, forKey: .avgPrice) ?? 0.0
        close = try container.decodeIfPresent(Double.self, forKey: .close) ?? 0.0
    }
}
