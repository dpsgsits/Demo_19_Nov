//
//  CoreDataManager.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//

internal import CoreData

enum StoreType: String {
    case sqlite
    case binary
    case inMemory
    
    func getStorageType() -> String {
        switch self {
        case .sqlite:
            return NSSQLiteStoreType
        case .binary:
            return NSBinaryStoreType
        case .inMemory:
            return NSInMemoryStoreType
        }
    }
}

final class CoreDataManager {

    private(set) var storeType: StoreType = .sqlite
    private(set) var error: Error?
    
    // MARK: - Singleton
    static let shared = CoreDataManager()

    // MARK: - Persistent Container
    let container: NSPersistentContainer

    // MARK: - Init
    private init() {
        container = NSPersistentContainer(name: "DilipParmarDemo")
    }
    
    func loadStore(storeType: StoreType, completionBlock: @escaping ((Error?) -> Void)) {
        let description = NSPersistentStoreDescription()
        description.type = storeType.getStorageType()
        container.persistentStoreDescriptions = [description]
        self.storeType = storeType
        container.loadPersistentStores { [weak self] _, error in
            if let error = error {
                self?.error = error
                completionBlock(error)
                assertionFailure("Core Data load error: \(error)")
            }
        }
    }

    // MARK: - Main Context
    lazy var mainContext: NSManagedObjectContext = {
        self.setConfigTo(context: container.viewContext)
        return container.viewContext
    }()
    
    private func setConfigTo(context: NSManagedObjectContext) {
        if context.hasChanges == false {
            context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
            context.automaticallyMergesChangesFromParent = true
            context.shouldDeleteInaccessibleFaults = true
            context.retainsRegisteredObjects = false
        }
    }

    // MARK: - Background Context
    func newBackgroundContext() -> NSManagedObjectContext {
        let context = container.newBackgroundContext()
        self.setConfigTo(context: context)
        return context
    }

    // MARK: - Save Any Context
    func save(context: NSManagedObjectContext) {
        if context.hasChanges {
            do { try context.save() }
            catch { print("Core Data save error:", error) }
        }
    }
    
    // MARK: - Fetch all entities
    final public func fetchAllOf<M: NSManagedObject>
        (type: M.Type) -> [M]? {
        var fetched: [M]?
        self.mainContext.performAndWait {
            let request = NSFetchRequest<M>.init(entityName: String(describing: type))
            request.returnsObjectsAsFaults = false
            fetched = try? self.mainContext.fetch(request)
        }
        return fetched
    }
    
    // MARK: - Delete all entities
    final public func deleteAllOf<M: NSManagedObject>(type: M.Type, context: NSManagedObjectContext) -> Bool {
        guard self.storeType == .sqlite else { return false }
        _ = context.performAndWait {
            let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: String(describing: type))
            let batchDeleteRequest = NSBatchDeleteRequest.init(fetchRequest: request)
            batchDeleteRequest.resultType = .resultTypeObjectIDs
            do {
                let batchResult = try context.execute(batchDeleteRequest) as? NSBatchDeleteResult
                let ids = batchResult?.result as? [NSManagedObjectID]
                if let ids = ids, ids.count > 0 {
                    let deletedObjects = [NSDeletedObjectsKey: ids]
                    NSManagedObjectContext.mergeChanges(fromRemoteContextSave: deletedObjects as [AnyHashable: Any],
                                                        into: [context, self.mainContext])
                }
                return true
            } catch let error {
                debugPrint("Error in \(#file) \(#function) \(#line) -- Error = \(error)")
                return false
            }
        }
        return true
    }
    
    func decode<M: NSManagedObject & Decodable>(type: M.Type, context: NSManagedObjectContext, data: Data) {
        do {
            let decoder = JSONDecoder()
            decoder.userInfo[.context] = context
            _ = try decoder.decode(type, from: data)
        } catch {
            print("Error: \(error)")
        }
    }
}

extension CodingUserInfoKey {
    static let context = CodingUserInfoKey(rawValue: "context")!
}

enum ContextError: Error {
    case contextNotFound
}
