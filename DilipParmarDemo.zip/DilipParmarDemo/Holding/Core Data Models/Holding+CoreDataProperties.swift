//
//  Holding+CoreDataProperties.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
//

public import Foundation
public import CoreData


public typealias HoldingCoreDataPropertiesSet = NSSet

extension Holding {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Holding> {
        return NSFetchRequest<Holding>(entityName: "Holding")
    }

    @NSManaged public var symbol: String?
    @NSManaged public var quantity: Int64
    @NSManaged public var ltp: Double
    @NSManaged public var avgPrice: Double
    @NSManaged public var close: Double
    @NSManaged public var holdingData: HoldingData?

}

extension Holding : Identifiable {

}
