//
//  UserHoldingVC.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//

import UIKit
internal import CoreData

struct HostingCell {
    static let reuseIdentifier = "UserHoldingCell"
}

class UserHoldingVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let tableView = UITableView()
    let viewModel = UserHoldingViewModel(networkManager: NetworkManager.shared)
    private var fetchedResultsController: NSFetchedResultsController<Holding>?
    private var expandableView: PortfolioView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        self.setupTableViewWithExpandableView()
        self.setupFRC()
        self.fetchData()
    }
    
    func setupTableViewWithExpandableView() {
        view.addSubview(self.tableView)
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        self.tableView.allowsSelection = false
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UserHoldingCell.self, forCellReuseIdentifier: HostingCell.reuseIdentifier)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.separatorInset = .zero
        
        self.expandableView = PortfolioView()
        self.expandableView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(self.expandableView)
        
        NSLayoutConstraint.activate([
            self.tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            self.tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            self.tableView.topAnchor.constraint(equalTo: view.topAnchor),
            
            self.expandableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            self.expandableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            self.expandableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            self.tableView.bottomAnchor.constraint(equalTo: self.expandableView.topAnchor)
        ])
    }
    
    private func fetchData() {
        Task {
            do {
                try await self.viewModel.fetchDataFrom(urlStr: ServerEndPoints.urlStr)
                print("current value = \(self.viewModel.currentValue)")
                print("Total investment = \(self.viewModel.totalInvestment)")
                print("Total PNL = \(self.viewModel.totalProfitLoss)")
                print("Today's PNL = \(self.viewModel.todaysProfitLoss)")
                Task { @MainActor in
                    self.expandableView.updateUI(viewModel: self.viewModel)
                }
            } catch {
                print("Error from NetworkManager - \(String(describing: error))")
            }
        }
    }
}

// MARK: FRC Setup
extension UserHoldingVC {

    func setupFRC() {

        let fetchRequest: NSFetchRequest<Holding> = Holding.fetchRequest()
        fetchRequest.sortDescriptors = [
            NSSortDescriptor(key: "symbol", ascending: true)
        ]

        fetchedResultsController = NSFetchedResultsController(
            fetchRequest: fetchRequest,
            managedObjectContext: CoreDataManager.shared.mainContext,
            sectionNameKeyPath: nil,
            cacheName: nil
        )

        fetchedResultsController?.delegate = self

        do {
            try fetchedResultsController?.performFetch()
        } catch {
            print("FRC fetch error:", error)
        }
    }
}

// MARK: Table View Delegate and Data Source methods
extension UserHoldingVC {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        fetchedResultsController?.sections?[section].numberOfObjects ?? 0
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        fetchedResultsController?.sections?.count ?? 1
    }

    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: HostingCell.reuseIdentifier, for: indexPath) as! UserHoldingCell
        if let model = fetchedResultsController?.object(at: indexPath) {
            cell.configure(with: model, viewModel: self.viewModel)
            cell.updateConstraintsIfNeeded()
        }
        return cell
    }
}

// MARK: FRC Delegate methods
extension UserHoldingVC: NSFetchedResultsControllerDelegate {

    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }

    func controller(
        _ controller: NSFetchedResultsController<NSFetchRequestResult>,
        didChange anObject: Any,
        at indexPath: IndexPath?,
        for type: NSFetchedResultsChangeType,
        newIndexPath: IndexPath?
    ) {
        switch type {
        case .insert:
            if let newIndexPath = newIndexPath {
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }

        case .delete:
            if let indexPath = indexPath {
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }

        case .update:
            if let indexPath = indexPath {
                tableView.reloadRows(at: [indexPath], with: .automatic)
            }
        case .move:
            if let indexPath = indexPath, let newIndexPath = newIndexPath {
                tableView.deleteRows(at: [indexPath], with: .automatic)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        @unknown default:
            break
        }
    }

    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
}
