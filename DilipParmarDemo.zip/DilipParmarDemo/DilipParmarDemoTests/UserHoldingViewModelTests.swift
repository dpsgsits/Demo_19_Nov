//
//  HostingViewModelTests.swift
//  DilipParmarDemoTests
//
//  Created by Dilip Parmar on 19/11/25.
//

import Testing
@testable import DilipParmarDemo
import Foundation
import CoreData

struct UserHoldingViewModelTests {

    @Test func testIncorrectURLError() async {
        
        let mockNetworkManager = MockNetworkManager()
        mockNetworkManager.shouldThrowError = true
        
        let viewModel = await UserHoldingViewModel(networkManager: mockNetworkManager)
        do {
            try await viewModel.fetchDataFrom(urlStr: "-abc-cde")
        } catch {
            let expectedError: NetworkingError = .incorrectURL
            #expect(error as! NetworkingError == expectedError)
        }
    }
    
    @Test func testProperAPIResponse() async {
        
        let mockNetworkManager = MockNetworkManager()
        mockNetworkManager.shouldThrowError = false
        
        let viewModel = await UserHoldingViewModel(networkManager: mockNetworkManager)
        do {
            try await viewModel.fetchDataFrom(urlStr: "abc.com")
            let userHoldings = await CoreDataManager.shared.fetchAllOf(type: Holding.self)
            #expect(userHoldings?.count ?? 0 > 0)
        } catch {
            
        }
    }
    
    @Test func testHoldingsCurrentValue() async {
        
        let mockNetworkManager = MockNetworkManager()
        
        let viewModel = await UserHoldingViewModel(networkManager: mockNetworkManager)
        do {
            try await viewModel.fetchDataFrom(urlStr: "abc.com")
            #expect(viewModel.currentValue > 0.0)
        } catch {
            
        }
    }
    
    @Test func testHoldingsTotalInvestment() async {
        
        let mockNetworkManager = MockNetworkManager()
        
        let viewModel = await UserHoldingViewModel(networkManager: mockNetworkManager)
        do {
            try await viewModel.fetchDataFrom(urlStr: "abc.com")
            #expect(viewModel.totalInvestment > 0.0)
        } catch {
            
        }
    }
    
    @Test func testHoldingsTotalProfitLoss() async {
        
        let mockNetworkManager = MockNetworkManager()
        
        let viewModel = await UserHoldingViewModel(networkManager: mockNetworkManager)
        do {
            try await viewModel.fetchDataFrom(urlStr: "abc.com")
            #expect(viewModel.totalProfitLoss > 0.0)
        } catch {
            
        }
    }
    
    @Test func testHoldingsTodaysProfitLoss() async {
        
        let mockNetworkManager = MockNetworkManager()
        
        let viewModel = await UserHoldingViewModel(networkManager: mockNetworkManager)
        do {
            try await viewModel.fetchDataFrom(urlStr: "abc.com")
            #expect(viewModel.todaysProfitLoss > 0.0)
        } catch {
            
        }
    }
}

class MockNetworkManager: NetworkServicable {
    var shouldThrowError: Bool = false
    
    func fetch(_ url: URL) async throws -> Data {
        if shouldThrowError {
            throw NetworkingError.incorrectURL
        }
        return """
            {
              "data": {
                "userHolding": [
                  {
                    "symbol": "MAHABANK",
                    "quantity": 990,
                    "ltp": 38.05,
                    "avgPrice": 35,
                    "close": 40
                  }
                ]
              }
            }
            """.data(using: .utf8)!
    }
}
