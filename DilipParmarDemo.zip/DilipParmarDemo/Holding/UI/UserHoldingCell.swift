//
//  UserHoldingCell.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//

import UIKit

class UserHoldingCell: UITableViewCell {
    
    let symbolLabel = UILabel()
    let quantityTextLabel = UILabel()
    let quantityValueLabel = UILabel()
    
    let ltpTextLabel = UILabel()
    let ltpValueLabel = UILabel()
    
    let pnlTextLabel = UILabel()
    let pnlValueLabel = UILabel()
    
    let mainStack = UIStackView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func setupUI() {
        
        symbolLabel.font = .boldSystemFont(ofSize: 18)
        quantityValueLabel.font = .systemFont(ofSize: 18)
        ltpValueLabel.font = .systemFont(ofSize: 18)
        pnlValueLabel.font = .systemFont(ofSize: 18)
        
        quantityTextLabel.font = .systemFont(ofSize: 14)
        quantityTextLabel.textColor = .systemGray
        
        ltpTextLabel.font = .systemFont(ofSize: 14)
        ltpTextLabel.textColor = .systemGray
        
        pnlTextLabel.font = .systemFont(ofSize: 14)
        pnlTextLabel.textColor = .systemGray
        
        let quantityStack = UIStackView(arrangedSubviews: [quantityTextLabel, quantityValueLabel])
        quantityStack.axis = .horizontal
        quantityStack.spacing = 8
        
        let leftStack = UIStackView(arrangedSubviews: [symbolLabel, quantityStack])
        leftStack.axis = .vertical
        leftStack.spacing = 8
        leftStack.alignment = .leading
        
        let ltpStack = UIStackView(arrangedSubviews: [ltpTextLabel, ltpValueLabel])
        ltpStack.axis = .horizontal
        ltpStack.spacing = 8
        
        let pnlStack = UIStackView(arrangedSubviews: [pnlTextLabel, pnlValueLabel])
        pnlStack.axis = .horizontal
        pnlStack.spacing = 8
        
        let rightStack = UIStackView(arrangedSubviews: [ltpStack, pnlStack])
        rightStack.axis = .vertical
        rightStack.spacing = 8
        rightStack.alignment = .trailing

        mainStack.axis = .horizontal
        mainStack.spacing = 8
        mainStack.addArrangedSubview(leftStack)
        mainStack.addArrangedSubview(rightStack)
        mainStack.distribution = .fillProportionally
        
        contentView.addSubview(mainStack)
        mainStack.translatesAutoresizingMaskIntoConstraints = false
                
        NSLayoutConstraint.activate([
            mainStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            mainStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            mainStack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            mainStack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12)
        ])
    }
    
    func configure(with holding: Holding, viewModel: UserHoldingViewModel) {
        symbolLabel.text = holding.symbol
        
        ltpTextLabel.text = "LTP:"
        ltpValueLabel.text = String(format: "₹%.2f", holding.ltp)
        
        pnlTextLabel.text = "P&L:"
        pnlValueLabel.text = String(format: "₹%.2f", viewModel.totalProfitLoss)

        quantityTextLabel.text = "NET QTY:"
        quantityValueLabel.text = "\(holding.quantity)"
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        symbolLabel.text = nil
        quantityTextLabel.text = nil
        quantityValueLabel.text = nil
        ltpTextLabel.text = nil
        ltpValueLabel.text = nil
        pnlTextLabel.text = nil
        pnlValueLabel.text = nil
    }
}
