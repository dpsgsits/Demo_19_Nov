//
//  PortfolioView.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 19/11/25.
//

import UIKit

enum PortfolioLabels: CaseIterable {
    case currValue
    case totalInvestment
    case todaysProfitLoss
}

final class PortfolioView: UIView, ExpandableViewDelegate {
    let currValueTextLabel = UILabel()
    let currValueLabel = UILabel()
    
    let totalInvestmentTextLabel = UILabel()
    let totalInvestmentValueLabel = UILabel()
    
    let todayProfitLossTextLabel = UILabel()
    let todayProfitLossValueLabel = UILabel()
    
    let totalProfitLossTextLabel = UILabel()
    let totalProfitLossValueLabel = UILabel()
    
    // Public
    let stackView = UIStackView()
    let profitLossView = ProfiltLossHeaderView()
    var minimumHeight: CGFloat = 60
    var animationDuration: TimeInterval = 0.15

    // Private
    private var heightConstraint: NSLayoutConstraint!
    
    // MARK: - Init
    init() {
        super.init(frame: .zero)
        self.backgroundColor = UIColor(red: 0.129, green: 0.149, blue: 0.141, alpha: 0.1)
        self.setupStackView()
        self.setupConstraints()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.backgroundColor = UIColor(red: 0.129, green: 0.149, blue: 0.141, alpha: 1.0)
        self.setupStackView()
        self.setupConstraints()
    }

    // MARK: - Setup
    private func setupStackView() {
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        self.addLabels()
        self.addSubview(self.profitLossView)
        self.addSubview(self.stackView)
        self.profitLossView.delegate = self
    }

    private func setupConstraints() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.profitLossView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            self.stackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            self.stackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            self.stackView.topAnchor.constraint(equalTo: topAnchor, constant: 16),
            
            self.profitLossView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            self.profitLossView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            self.profitLossView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16),
        ])

        self.heightConstraint = heightAnchor.constraint(equalToConstant: self.minimumHeight)
        self.heightConstraint.isActive = true
        
        //By default, stack view is hidden
        self.stackView.isHidden = true
    }

    // MARK: - Expand / Collapse
    func toggle(isExpanded: Bool) {
        isExpanded ? self.collapse(isExpanded: isExpanded) : self.expand(isExpanded: isExpanded)
    }

    func expand(isExpanded: Bool) {
        guard !isExpanded else { return }
        // Ensure layout so measurement is correct
        self.layoutIfNeeded()

        self.heightConstraint.constant = 180
        self.animateLayout {
            self.stackView.isHidden = false
        }
    }

    func collapse(isExpanded: Bool) {
        guard isExpanded else { return }
        self.heightConstraint.constant = minimumHeight
        self.stackView.isHidden = true
        self.animateLayout()
    }

    private func animateLayout(completion: (() -> Void)? = nil) {
        UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut]) {
            self.superview?.layoutIfNeeded() // animate constraints relative to superview
            self.layoutIfNeeded()
        } completion: { _ in
            completion?()
        }
    }
    
    func expandableViewButtonTapped(isExpanded: Bool) {
        self.toggle(isExpanded: isExpanded)
    }
    
    private func addLabels() {
        var leftLabel: UILabel!
        var rightLabel: UILabel!
        for label in PortfolioLabels.allCases {
            let containerStack = UIStackView()
            containerStack.axis = .horizontal
            containerStack.alignment = .fill
            containerStack.distribution = .fill
            containerStack.spacing = 8
            
            switch label {
            case .currValue:
                leftLabel = self.currValueTextLabel
                rightLabel = self.currValueLabel
            case .totalInvestment:
                leftLabel = self.totalInvestmentTextLabel
                rightLabel = self.totalInvestmentValueLabel
            case .todaysProfitLoss:
                leftLabel = self.todayProfitLossTextLabel
                rightLabel = self.todayProfitLossValueLabel
            }
            leftLabel.translatesAutoresizingMaskIntoConstraints = false
            rightLabel.translatesAutoresizingMaskIntoConstraints = false
 
            containerStack.addArrangedSubview(leftLabel)
            containerStack.addArrangedSubview(rightLabel)
            
            self.stackView.addArrangedSubview(containerStack)
        }
        //Add divider
        let divider = UIView()
        divider.backgroundColor = .lightGray
        divider.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            divider.heightAnchor.constraint(equalToConstant: 1)
        ])
        self.stackView.addArrangedSubview(divider)
        self.stackView.layoutIfNeeded()
        self.stackView.updateConstraintsIfNeeded()
    }
    
    func updateUI(viewModel: HoldingsPresentable) {
        for label in PortfolioLabels.allCases {
            switch label {
            case .currValue:
                self.currValueTextLabel.text = "Current value*"
                self.currValueLabel.text = String(format: "₹ %.2f", viewModel.currentValue)
                self.currValueLabel.textAlignment = .right
                
            case .totalInvestment:
                self.totalInvestmentTextLabel.text = "Total investment*"
                self.totalInvestmentValueLabel.text = String(format: "₹ %.2f", viewModel.totalInvestment)
                self.totalInvestmentValueLabel.textAlignment = .right
                
            case .todaysProfitLoss:
                self.todayProfitLossTextLabel.text = "Today's Profit & Loss*"
                self.todayProfitLossValueLabel.text = String(format: "₹%.2f", viewModel.todaysProfitLoss)
                self.todayProfitLossValueLabel.textAlignment = .right
            }
        }
        self.profitLossView.updateUI(totalProfitLoss: viewModel.totalProfitLoss)
        self.stackView.updateConstraintsIfNeeded()
        self.stackView.layoutIfNeeded()
    }
}


protocol ExpandableViewDelegate: AnyObject {
    func expandableViewButtonTapped(isExpanded: Bool)
}

class ProfiltLossHeaderView: UIView {
    let stackView = UIStackView()
    let titleLabel = UILabel()
    let valueLabel = UILabel()
    let button = UIButton()

    private var isExpanded = false
    weak var delegate: ExpandableViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.setup()
    }

    private func setup() {
        
        self.stackView.axis = .horizontal
        self.stackView.alignment = .fill
        self.stackView.distribution = .fill
        self.stackView.spacing = 8
        
        self.titleLabel.text = "Profit & Loss*"
        self.titleLabel.textAlignment = .left
        self.titleLabel.translatesAutoresizingMaskIntoConstraints = false

        self.valueLabel.textAlignment = .right
        self.valueLabel.translatesAutoresizingMaskIntoConstraints = false

        self.button.setImage(UIImage(systemName: "chevron.up"), for: .normal)
        self.button.translatesAutoresizingMaskIntoConstraints = false
        self.button.addTarget(self, action: #selector(didTap), for: .touchUpInside)
        self.button.tintColor = .black
        
        let spacer = UIView()
        spacer.setContentHuggingPriority(.defaultLow, for: .horizontal)
        
        self.stackView.translatesAutoresizingMaskIntoConstraints = false
        self.stackView.addArrangedSubview(self.titleLabel)
        self.stackView.addArrangedSubview(self.button)
        self.stackView.addArrangedSubview(spacer)
        self.stackView.addArrangedSubview(self.valueLabel)
        addSubview(self.stackView)

        NSLayoutConstraint.activate([
            self.stackView.topAnchor.constraint(equalTo: topAnchor),
            self.stackView.bottomAnchor.constraint(equalTo: bottomAnchor),
            self.stackView.leadingAnchor.constraint(equalTo: leadingAnchor),
            self.stackView.trailingAnchor.constraint(equalTo: trailingAnchor),
            self.stackView.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func updateUI(totalProfitLoss: Double) {
        self.valueLabel.text = String(format: "₹%.2f", totalProfitLoss)
        self.stackView.layoutIfNeeded()
        self.layoutIfNeeded()
    }
    
    @objc private func didTap() {
        self.delegate?.expandableViewButtonTapped(isExpanded: self.isExpanded)
        self.isExpanded.toggle()
        self.button.setImage(UIImage(systemName: self.isExpanded ? "chevron.down" : "chevron.up"), for: .normal)
    }
}
