//
//  UserHoldingViewModel.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//

import NetworkExtension
internal import CoreData

struct ServerEndPoints {
    static let urlStr = "https://35dee773a9ec441e9f38d5fc249406ce.api.mockbin.io/"
}

enum NetworkingError: Error {
    case incorrectURL
}

protocol HoldingsPresentable{
    var currentValue: Double { get }
    var totalInvestment: Double { get }
    var totalProfitLoss: Double { get }
    var todaysProfitLoss: Double { get }
}

class UserHoldingViewModel: HoldingsPresentable {

    private var networkManager: NetworkServicable
    private let coreDataManager = CoreDataManager.shared
    
    init(networkManager: NetworkServicable = NetworkManager.shared) {
        self.networkManager = networkManager
    }
    
    func fetchDataFrom(urlStr: String) async throws {
        guard let urlFound = URL(string: urlStr) else {
            throw NetworkingError.incorrectURL
        }
        let dataReceived = try await self.networkManager.fetch(urlFound)
        self.saveToDB(data: dataReceived)
    }
    
    func saveToDB(data: Data) {
        guard data.count > 0 else { return }
        let context = self.coreDataManager.newBackgroundContext()
        _ = self.coreDataManager.deleteAllOf(type: HoldingMainModel.self, context: context)
        _ = self.coreDataManager.deleteAllOf(type: Holding.self, context: context)
        self.coreDataManager.decode(type: HoldingMainModel.self, context: context, data: data)
        self.coreDataManager.save(context: context)
    }
    
    var currentValue: Double {
        let allHoldings = self.coreDataManager.fetchAllOf(type: Holding.self)
        if let holdingsFound = allHoldings {
            let ltpTimesQuantity = holdingsFound.map { holding in
                holding.ltp * Double(holding.quantity)
            }
            return ltpTimesQuantity.reduce(0.0, +)
        }
        return 0.0
    }
    
    var totalInvestment: Double {
        let allHoldings = self.coreDataManager.fetchAllOf(type: Holding.self)
        if let holdingsFound = allHoldings {
            let totalInvestments = holdingsFound.map { holding in
                holding.avgPrice * Double(holding.quantity)
            }
            return totalInvestments.reduce(0.0, +)
        }
        return 0.0
    }
    
    var totalProfitLoss: Double {
        self.currentValue - self.totalInvestment
    }
    
    var todaysProfitLoss: Double {
        let allHoldings = self.coreDataManager.fetchAllOf(type: Holding.self)
        if let holdingsFound = allHoldings {
            let todaysProfileLoss = holdingsFound.map { holding in
                (holding.close - holding.ltp) * Double(holding.quantity)
            }
            return todaysProfileLoss.reduce(0.0, +)
        }
        return 0.0
    }
}
