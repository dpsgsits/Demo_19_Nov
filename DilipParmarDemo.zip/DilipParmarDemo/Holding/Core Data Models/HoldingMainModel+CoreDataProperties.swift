//
//  HoldingMainModel+CoreDataProperties.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
//

public import Foundation
public import CoreData


public typealias HoldingMainModelCoreDataPropertiesSet = NSSet

extension HoldingMainModel {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<HoldingMainModel> {
        return NSFetchRequest<HoldingMainModel>(entityName: "HoldingMainModel")
    }

    @NSManaged public var holdingData: HoldingData?

}

extension HoldingMainModel : Identifiable {

}
