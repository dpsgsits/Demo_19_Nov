//
//  NetworkManager.swift
//  DilipParmarDemo
//
//  Created by Dilip Parmar on 18/11/25.
//
import NetworkExtension

//Protocol to be confirmed by concrete type for fetching data.
protocol NetworkServicable {
  func fetch(_ url: URL) async throws -> Data
}

//Network manager class for making network calls. It's singleton to use connection pooling from URLSession.
final class NetworkManager: NetworkServicable {
    static let shared = NetworkManager()
    
    private let session: URLSession

    private init() {
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        config.timeoutIntervalForRequest = 5
        config.timeoutIntervalForResource = 10
        session = URLSession(configuration: config)
    }

    func fetch(_ url: URL) async throws -> Data {
        let (data, _) = try await session.data(from: url)
        return data
    }
}
